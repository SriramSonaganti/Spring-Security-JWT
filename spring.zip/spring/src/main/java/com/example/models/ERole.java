package com.example.models;

public enum ERole {
	ROLE_USER,
    ROLE_EMPLOYEE,
    ROLE_ADMIN
}
